export { ProfilePage } from "./page";
